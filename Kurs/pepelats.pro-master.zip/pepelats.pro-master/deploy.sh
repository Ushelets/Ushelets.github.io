git add .
git commit -am "Deploy in Heroku"
git push heroku master