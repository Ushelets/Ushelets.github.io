export default [
  {
    email: 'mail@mail.ru',
    password: 'asdasdasd'
  },
  {
    email: 'mail@mail.ru',
    password: ''
  },
  {
    email: '',
    password: 'asdasdasd'
  },
  {
    email: 'asd==**!!!<>><!=@mail.ru',
    password: 'asdasdasd'
  },
  {
    email: 'asd@mail.ru',
    password: 'assd'
  },
  {
    email: 'asd@mail.ru',
    password: 'asdasd'
  }
]
