export default [
  {
    email: 'mail@mail.ru',
    password: 'asdasdasd',
    repassword: 'asdasdasd'
  },
  {
    email: 'mail@mail.ru',
    password: '',
    repassword: 'asdasdasd'
  },
  {
    email: '',
    password: 'asdasdasd',
    repassword: 'asdasdasd'
  },
  {
    email: 'asd==**!!!<>><!=@mail.ru',
    password: 'asdasdasd',
    repassword: 'asdasdasd'
  },
  {
    email: 'asd@mail.ru',
    password: 'asasd',
    repassword: 'asasd'
  },
  {
    email: 'asd@mail.ru',
    password: 'asdasd',
    repassword: 'asd'
  }
]
