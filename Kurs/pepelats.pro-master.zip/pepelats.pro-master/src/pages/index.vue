<template>
  <div class="index">
    <img src="../assets/img/logo_black.png">
    <div class="input">
      <router-link tag="a" to="/vuejs"><h3>ВХОД НА САЙТ</h3></router-link>
    </div>    
  </div>
</template>

<script>

</script>

<style lang="stylus" scoped>
@import '../assets/style/index'
</style>
