<template>
  <auth-form></auth-form>
</template>

<script>
import authForm from '../components/authForm.vue'
export default {
  components: {
    authForm
  }
}
</script>
